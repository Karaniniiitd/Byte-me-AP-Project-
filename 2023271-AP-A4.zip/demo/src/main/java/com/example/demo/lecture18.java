package com.example.demo;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

import static javafx.application.Application.launch;

public class lecture18 extends Application {
    Stage window;
    TableView<Product> table;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        window = stage;
        window.setTitle("Lecture 18");
        //name column;
        TableColumn<Product, String> nameCol = new TableColumn<>("Name");
        nameCol.setMinWidth(200);
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        //price column
        TableColumn<Product, String> priceCol = new TableColumn<>("Price");
        priceCol.setMinWidth(200);
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        //Quantity column
        TableColumn<Product, String> quantityCol = new TableColumn<>("quantity");
        quantityCol.setMinWidth(200);
        quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        table = new TableView<>();
        table.setItems(getProducts());
        table.getColumns().addAll(nameCol, priceCol, quantityCol);
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(table);
        Scene scene = new Scene(vbox);
        window.setScene(scene);
        window.show();



    }
    public ObservableList<Product> getProducts() {
        ObservableList<Product> products= FXCollections.observableArrayList();
        products.add(new Product("Lapt0p",1000,2));
        products.add(new Product("Note",100,2));
        products.add(new Product("Plate",150,2));
        return products;

    }
}
