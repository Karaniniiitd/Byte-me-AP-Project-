package com.example.demo;
import javafx.application.Platform;

import java.time.LocalDate;
import java.util.*;
import java.io.*;
public class Customer extends Users {
    boolean VipStatus=false;
    public static List<Customer>CustomersList=new ArrayList<>();
    public List<CustomerFoodItems> cart=new ArrayList<>();
    public Customer(String emailid, String password,boolean VipStatus) {
        super(emailid, password);
        this.VipStatus = VipStatus;
        CustomersList.add(this);
    }
    public boolean getVipStatus() {
        return VipStatus;
    }
    public void setVipStatus(boolean VipStatus) {
        this.VipStatus = VipStatus;
    }
    public List<CustomerFoodItems> getCart() {
        return cart;
    }
    public void displayCart() {
        for(CustomerFoodItems c:cart) {
            System.out.println("----------------");
            System.out.println("Food name : "+c.getName());
            System.out.println("Food price : "+c.getPrice());
            System.out.println("Food category : "+c.getCategory());
            System.out.println("Food availability : "+c.getAvailability());
            System.out.println("Food quantity : "+c.getQuantity());
            System.out.println("----------------");
        }
    }
    public void beingVIP() {
        if(VipStatus==true){
            System.out.println("You are already a VIP customer!");
            return;
        }
        Scanner input = new Scanner(System.in);
        int totalRefund = 0;
        boolean vipPurchased = false;

        while (!vipPurchased) {
            System.out.println("Pay Rs 500 to become a VIP Customer!");
            int money = input.nextInt();

            if (money > 500) {
                int refund = money - 500;
                totalRefund += refund;
                System.out.println("You have given more than Rs 500! Rs " + refund + " will be refunded.");
                System.out.println("Please try again with the correct amount.");

            } else if (money < 500) {
                totalRefund += money; // Add any amount less than 500 to totalRefund
                System.out.println("Insufficient money. Rs " + money + " added to refund. Please provide exactly Rs 500 to proceed.");

            } else {
                System.out.println("You have provided Rs 500 exactly. You are now a VIP Customer!");
                this.VipStatus = true;
                System.out.println("Thank you! Enjoy the VIP services.");

                if (totalRefund > 0) {
                    System.out.println("Your total refunded amount from previous attempts is Rs " + totalRefund + ".");
                }
                vipPurchased = true;
            }
        }
    }


    public void viewitems(){
        for(FoodItems foodItems:FoodItems.FoodItemsList){
            System.out.println("-------------------");
            System.out.println("Food name : "+foodItems.getName());
            System.out.println("Food price : "+foodItems.getPrice());
            System.out.println("Food category : "+foodItems.getCategory());
            System.out.println("Food availability : "+foodItems.getAvailability());
            System.out.println("-------------------");
        }
    }
    public void EnterGUIMode() {
        Platform.runLater(() -> MainMenu.display());
    }
    public void searchitems() {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter Food name:");
        String foodname=input.nextLine();
        boolean found=false;
        for(FoodItems foodItems:FoodItems.FoodItemsList){
            if(foodItems.getName().equals(foodname)){
                found=true;
                System.out.println("-------------------");
                System.out.println("Food name : "+foodItems.getName());
                System.out.println("Food price : "+foodItems.getPrice());
                System.out.println("Food category : "+foodItems.getCategory());
                System.out.println("Food availability : "+foodItems.getAvailability());
                System.out.println("-------------------");
                break;
            }

        }
        if(found==false){
            System.out.println("No such food");
        }


    }
    public void filterbycategory(){
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the category: ");
        String category=input.nextLine();
        boolean found=false;
        for(FoodItems foodItems:FoodItems.FoodItemsList){
            if(foodItems.getCategory().equals(category)){
                found=true;
                System.out.println("-------------------");
                System.out.println("Food name : "+foodItems.getName());
                System.out.println("Food price : "+foodItems.getPrice());
                System.out.println("Food category : "+foodItems.getCategory());
                System.out.println("Food availability : "+foodItems.getAvailability());
                System.out.println("-------------------");


            }
        }
        if(found==false){
            System.out.println("No such category");
        }
    }
    public void sortbyprices(){
        Collections.sort(FoodItems.FoodItemsList);
        for (FoodItems foodItems : FoodItems.FoodItemsList) {
            System.out.println("-------------------");
            System.out.println("Food name : "+foodItems.getName());
            System.out.println("Food price : "+foodItems.getPrice());
            System.out.println("Food category : "+foodItems.getCategory());
            System.out.println("Food availability : "+foodItems.getAvailability());
            System.out.println("-------------------");

        }
    }
    public void additems() {
        Scanner input = new Scanner(System.in);
        // Check if any items in the cart are checked out
        if (cart.stream().anyMatch(CustomerFoodItems::isCheckedOut)) {
            System.out.println("You have already checked out this order. Please start a new order to add items.");
            return;
        }

        while (true) {
            // Prompt for food item name
            System.out.println("Food item name: ");
            String name = input.nextLine();

            // Search for the food item in the list
            FoodItems selectedItem = null;
            for (FoodItems foodItems : FoodItems.FoodItemsList) {
                if (foodItems.getName().equals(name)) {
                    selectedItem = foodItems;
                    System.out.println("-------------------");
                    System.out.println("Food name: " + foodItems.getName());
                    System.out.println("Food price: " + foodItems.getPrice());
                    System.out.println("Food category: " + foodItems.getCategory());
                    System.out.println("Food availability: " + foodItems.getAvailability());
                    System.out.println("-------------------");
                    break;
                }
            }

            // If no matching item was found, exit the function
            if (selectedItem == null) {
                System.out.println("No such food.");
                return;
            }

            // Prompt for quantity and validate it
            int quantity;
            while (true) {
                System.out.println("Give quantity of " + name + ":");
                quantity = input.nextInt();
                input.nextLine(); // Consume the newline character
                if (quantity <= 0) {
                    System.out.println("Quantity must be a positive number. Please try again.");
                } else {
                    break;
                }
            }

            // Check if enough items are available
            if (selectedItem.getAvailability() < quantity) {
                System.out.println("Not enough items in stock! Available quantity: " + selectedItem.getAvailability());
                continue;
            }

            System.out.println("Any special request (if not, type 'null'): ");
            String specialRequest = input.nextLine();

            // Add the selected item to the cart
            CustomerFoodItems c = new CustomerFoodItems(selectedItem.getPrice(), selectedItem.getName(),
                    selectedItem.getCategory(), selectedItem.getAvailability(), quantity, specialRequest,false);
            cart.add(c);
            SpecialRequest specialRequestObj = new SpecialRequest(this.emailid, this.password, this.VipStatus, specialRequest);

            // Update availability
            selectedItem.setAvailability(selectedItem.getAvailability() - quantity);
            System.out.println("Your food item has been added to the cart successfully!");

            // Ask if the user wants to add more items
            System.out.print("Do you want to add another item? (yes/no): ");
            String choice = input.nextLine();

            if (!choice.equalsIgnoreCase("yes")) {
                System.out.println("Thank you for your order!");
                break;
            }
        }
    }

    public void modifyquantity(){
        // Check if any items in the cart are checked out
        if (cart.stream().anyMatch(CustomerFoodItems::isCheckedOut)) {
            System.out.println("You have already checked out this order. Please start a new order to modify items.");
            return;
        }
        if(cart==null||cart.isEmpty()){
            System.out.println("Oops Your cart is empty! may be you have not ordered something.");
            return;
        }
        Scanner input=new Scanner(System.in);
        System.out.println("Your Cart details : ");
        for(CustomerFoodItems c:cart){
            System.out.println("----------------");
            System.out.println("Food name : "+c.getName());
            System.out.println("Food price : "+c.getPrice());
            System.out.println("Food category : "+c.getCategory());
            System.out.println("Food availability : "+c.getAvailability());
            System.out.println("Food quantity : "+c.getQuantity());
            System.out.println("----------------");
        }
        System.out.println("For which fooditems you want modify quantity : ");
        String name=input.nextLine();
        for (CustomerFoodItems c : cart) {
            if (c.getName().equals(name)) {
                int quantity;
                while (true) {
                    System.out.println("Give new quantity of " + name + ":");
                    quantity = input.nextInt();
                    input.nextLine(); // Consume the newline character
                    if (quantity <= 0) {
                        System.out.println("Quantity must be a positive number. Please try again.");
                    } else {
                        break;
                    }
                }
                c.setQuantity(quantity);
                System.out.println("Your food item's quantity has been modified in the cart successfully!");
            }
        }
    }
    public void viewcart(){
        if(cart==null||cart.isEmpty()){
            System.out.println("Oops your cart is empty! may be you have not ordered something.");
            return;
        }
        for (CustomerFoodItems c : cart) {
            System.out.println("----------------");
            System.out.println("Food name : "+c.getName());
            System.out.println("Food price : "+c.getPrice());
            System.out.println("Food category : "+c.getCategory());
            System.out.println("Food availability : "+c.getAvailability());
            System.out.println("Food quantity : "+c.getQuantity());
            System.out.println("----------------");
        }
    }
    public void removeitems() {
        // Check if any items in the cart are checked out
        if (cart.stream().anyMatch(CustomerFoodItems::isCheckedOut)) {
            System.out.println("You have already checked out this order. Please start a new order to remove items.");
            return;
        }
        if (cart == null || cart.isEmpty()) {
            System.out.println("Oops, your cart is empty! You may not have ordered anything.");
            return;
        }

        Scanner input = new Scanner(System.in);
        System.out.println("Your Cart details:");
        for (CustomerFoodItems c : cart) {
            System.out.println("----------------");
            System.out.println("Food name: " + c.getName());
            System.out.println("Food price: " + c.getPrice());
            System.out.println("Food category: " + c.getCategory());
            System.out.println("Food availability: " + c.getAvailability());
            System.out.println("Food quantity: " + c.getQuantity());
            System.out.println("----------------");
        }

        System.out.println("Enter the name of the food item you want to remove: ");
        String name = input.nextLine();
        boolean found = false;

        // Use an iterator to remove items safely
        Iterator<CustomerFoodItems> iterator = cart.iterator();
        while (iterator.hasNext()) {
            CustomerFoodItems c = iterator.next();
            if (c.getName().equals(name)) {
                found = true;
                iterator.remove(); // Safely removes the item from cart
                System.out.println("Your food item has been removed from the cart successfully!");
                break;
            }
        }

        if (!found) {
            System.out.println("You have entered an incorrect food name!");
        }
    }

    public int viewtotal(){
        int totalbill=0;
        for(CustomerFoodItems c:cart){
            totalbill=totalbill+c.getPrice()*c.getQuantity();
        }
        for(CustomerFoodItems c:cart){
            System.out.println("----------------");
            System.out.println("Food name: " + c.getName());
            System.out.println("Food price: " + c.getPrice());
            System.out.println("Food category: " + c.getCategory());
            System.out.println("Food availability: " + c.getAvailability());
            System.out.println("Food quantity: " + c.getQuantity());
            System.out.println("----------------");
        }
        System.out.println("Total Bill : Rs "+totalbill);
        return totalbill;

    }
    public void checkoutprocess() {
        Scanner input = new Scanner(System.in);

        // Check if the cart is empty
        if (cart == null || cart.isEmpty()) {
            System.out.println("Oops, your cart is empty! Maybe you haven't added anything.");
            return;
        }

        // Check for any existing order with a status that prevents checkout
        boolean hasActiveOrder = false;
        for (Order order : Order.Orderlist.keySet()) {
            if (Order.Orderlist.get(order).equals(this) &&
                    (order.getOrderstatus().equalsIgnoreCase("Out for Delivery") ||
                            order.getOrderstatus().equalsIgnoreCase("Delivered") ||
                            order.getOrderstatus().equalsIgnoreCase("Order Received") ||
                            order.getOrderstatus().equalsIgnoreCase("Preparing") ||
                            order.getOrderstatus().equalsIgnoreCase("Denied"))) {

                hasActiveOrder = true;
                break;
            }
        }

        if (hasActiveOrder) {
            System.out.println("You already have an active order that prevents checkout. Please wait for it to complete or contact support.");

            return;
        }

        // Calculate total bill
        int totalBill = viewtotal();
        System.out.println("Total bill: Rs " + totalBill);
        System.out.println("Enter your address: ");
        String address = input.nextLine();

        int refundAmount = 0;
        while (true) {
            System.out.println("Please pay the exact amount (Rs " + totalBill + "): ");
            int amount = input.nextInt();
            input.nextLine(); // consume the newline character

            // Check if amount is exactly correct
            if (amount == totalBill) {
                System.out.println("Payment successful. Processing your order...");
                long orderId = System.currentTimeMillis();
                Order order = new Order(this.emailid, this.password, this.VipStatus, "pending", LocalDate.now(),new ArrayList<>(cart),orderId);
                order.setOrderID(orderId);
                Order.Orderlist.put(order, this);
                orderreceipt(address);
                saveOrderToFile(order, address);
                System.out.println("Thank you for your payment! Enjoy your order.");
                for (CustomerFoodItems item : cart) {
                    item.setCheckedOut(true);
                }
                break;
            }
            // Handle overpayment
            else if (amount > totalBill) {
                refundAmount += (amount - totalBill);
                System.out.println("You overpaid by Rs " + (amount - totalBill) + ". Rs " + refundAmount + " will be refunded.");
                System.out.println("Please try again with the correct amount.");
            }
            // Handle underpayment
            else {
                System.out.println("Insufficient payment. You need to pay exactly Rs " + totalBill + ".");
                System.out.println("Please try again.");
            }
        }

        // Show total refunded amount if any
        if (refundAmount > 0) {
            System.out.println("Total refunded amount: Rs " + refundAmount);
        }
    }
    private void saveOrderToFile(Order order, String address) {
        File file = new File("orders.txt");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) { // Open file in append mode
            writer.write("Order ID: " + order.getOrderID());
            writer.newLine();
            writer.write("Order Details:");
            writer.newLine();
            writer.write("Customer Email: " + order.getEmailid());
            writer.newLine();
            writer.write("VIP Status: " + order.getVipStatus());
            writer.newLine();
            writer.write("Order Status: " + order.getOrderstatus());
            writer.newLine();
            writer.write("Order Date: " + order.getOrderdate());
            writer.newLine();
            writer.write("Delivery Address: " + address);
            writer.newLine();
            writer.write("Cart Details:");
            writer.newLine();
            for (CustomerFoodItems item : cart) {
                writer.write("  - Food Name: " + item.getName());
                writer.write(", Price: " + item.getPrice());
                writer.write(", Category: " + item.getCategory());
                writer.write(", Quantity: " + item.getQuantity());
                writer.newLine();
            }
            writer.write("------");
            writer.newLine();
            writer.flush();
            System.out.println("Order details saved to file successfully.");
        } catch (IOException e) {
            System.out.println("Error saving order to file: " + e.getMessage());
        }
    }

    public void orderreceipt(String address){
        System.out.println("---------------------");
//        for(CustomerFoodItems c:cart){
//            System.out.println("----------------");
//            System.out.println("Food name : "+c.getName());
//            System.out.println("Food price : "+c.getPrice());
//            System.out.println("Food category : "+c.getCategory());
//            System.out.println("Food availability : "+c.getAvailability());
//            System.out.println("Food quantity : "+c.getQuantity());
//            System.out.println("----------------");
//        }
        viewtotal();
        System.out.println(address);
        System.out.println("---------------------");


    }
    public void vieworderstatus() {
        boolean orderFound = false;

        // First, look for active orders in Order.Orderlist
        for (Map.Entry<Order, Customer> entry : Order.Orderlist.entrySet()) {
            Order order = entry.getKey();
            Customer customer = entry.getValue();

            if (customer.equals(this)) {
                orderFound = true;
                System.out.println("Active Order Status: " + order.getOrderstatus());
                System.out.println("Order Details:");

                // Retrieve items directly from the order
                if (order.getItems() != null && !order.getItems().isEmpty()) {
                    for (CustomerFoodItems item : order.getItems()) {
                        System.out.println("----------------");
                        System.out.println("Food name: " + item.getName());
                        System.out.println("Food price: Rs " + item.getPrice());
                        System.out.println("Food category: " + item.getCategory());
                        System.out.println("Food availability: " + item.getAvailability());
                        System.out.println("Food quantity: " + item.getQuantity());
                        System.out.println("----------------");
                    }
                } else {
                    System.out.println("No items in this order.");
                }

                System.out.println("Order placed by: " + this.getEmailid());
                break;
            }
        }

        // If no active orders found, check CompletedOrders
        if (!orderFound) {
            // Iterate over the completedOrderList
            for (CompletedOrder completedOrder : CompletedOrders.completedOrderList) {
                Order order = completedOrder.getOrder();       // Assuming CompletedOrder has getOrder() method
                Customer customer = completedOrder.getCustomer(); // Assuming CompletedOrder has getCustomer() method

                if (customer.equals(this)) {
                    orderFound = true;
                    System.out.println("Completed Order Status: " + order.getOrderstatus());
                    System.out.println("Order Details:");

                    // Retrieve items from the completed order
                    if (order.getItems() != null && !order.getItems().isEmpty()) {
                        for (CustomerFoodItems item : order.getItems()) {
                            System.out.println("----------------");
                            System.out.println("Food name: " + item.getName());
                            System.out.println("Food price: Rs " + item.getPrice());
                            System.out.println("Food category: " + item.getCategory());
                            System.out.println("Food availability: " + item.getAvailability());
                            System.out.println("Food quantity: " + item.getQuantity());
                            System.out.println("----------------");
                        }
                    } else {
                        System.out.println("No items in this order.");
                    }

                    System.out.println("Order placed by: " + this.getEmailid());
                    break;
                }
            }

        }

        // Notify if no orders (active or completed) were found for this customer
        if (!orderFound) {
            System.out.println("You have no orders placed.");
        }
    }
    public void cancelorder() {
        Scanner input = new Scanner(System.in);
        boolean orderFound = false;

        for (Map.Entry<Order, Customer> entry : Order.Orderlist.entrySet()) {
            Order order = entry.getKey();
            Customer customer = entry.getValue();

            // Check if the order belongs to this customer
            if (customer.equals(this)) {
                orderFound = true;

                // Display order details and current status
                System.out.println("Order Status: " + order.getOrderstatus());
                System.out.println("Order Details:");
                for (CustomerFoodItems c : cart) {
                    System.out.println("----------------");
                    System.out.println("Food name: " + c.getName());
                    System.out.println("Food price: " + c.getPrice());
                    System.out.println("Food category: " + c.getCategory());
                    System.out.println("Food availability: " + c.getAvailability());
                    System.out.println("Food quantity: " + c.getQuantity());
                    System.out.println("----------------");
                }
                System.out.println("Order placed by: " + this.getEmailid());

                // Check if the order can be cancelled (only if status is "Pending")
                if (order.getOrderstatus().equalsIgnoreCase("pending")) {
                    // Prompt for confirmation to cancel
                    System.out.print("Are you sure you want to cancel this order? (yes/no): ");
                    String confirmation = input.nextLine();

                    if (confirmation.equalsIgnoreCase("yes")) {
                        // Update order status to "Cancelled"
                        order.setOrderstatus("Cancelled");
                        System.out.println("Your order has been successfully cancelled. Wait for the admin to cancel your order!");
                    } else {
                        System.out.println("Order cancellation aborted.");
                    }
                } else {
                    // If the order status is not "Pending", cancellation is not allowed
                    System.out.println("Sorry, your order cannot be cancelled as it is no longer pending.");
                }
                break;
            }
        }

        // If no order was found for this customer, notify them
        if (!orderFound) {
            System.out.println("You have no orders placed.");
        }
    }

    public void viewyourorderhistory() {
        boolean orderFound = false;

        System.out.println("Order History (Delivered Orders):");

        // Loop through the completedOrderList to find delivered orders belonging to this customer
        for (CompletedOrder completedOrder : CompletedOrders.completedOrderList) {
            Order order = completedOrder.getOrder();           // Assuming getOrder() method in CompletedOrder
            Customer customer = completedOrder.getCustomer();   // Assuming getCustomer() method in CompletedOrder

            // Check if the order belongs to this customer and is delivered
            if (customer.equals(this) && "Delivered".equalsIgnoreCase(order.getOrderstatus())||"Denied".equalsIgnoreCase(order.getOrderstatus())) {
                orderFound = true;
                System.out.println("----------------------------");
                System.out.println("Order Status: " + order.getOrderstatus());
                System.out.println("Order Date: " + order.getOrderdate());
                System.out.println("Order Details:");

                // Retrieve items from the completed order
                if (order.getItems() != null && !order.getItems().isEmpty()) {
                    for (CustomerFoodItems item : order.getItems()) {
                        System.out.println("----------------");
                        System.out.println("Food name: " + item.getName());
                        System.out.println("Food price: Rs " + item.getPrice());
                        System.out.println("Food category: " + item.getCategory());
                        System.out.println("Food availability: " + item.getAvailability());
                        System.out.println("Food quantity: " + item.getQuantity());
                        System.out.println("----------------");
                    }
                } else {
                    System.out.println("No items in this order.");
                }

                System.out.println("Order placed by: " + this.getEmailid());
                System.out.println("----------------------------");
            }
        }

        // If no delivered orders are found, inform the customer
        if (!orderFound) {
            System.out.println("You have no delivered orders in your order history.");
        }
    }


    public void provideReview() {
        Scanner input = new Scanner(System.in);
        List<CompletedOrder> deliveredOrders = new ArrayList<>();

        // Display delivered order history with serial numbers
        System.out.println("Delivered Order History:");
        int serialNumber = 1;

        for (CompletedOrder completedOrder : CompletedOrders.completedOrderList) {
            Customer customer = completedOrder.getCustomer();
            if (customer.equals(this)) { // Check if the completed order belongs to the current customer
                System.out.println(serialNumber + ". Order Date: " + completedOrder.getOrder().getOrderdate() +
                        ", Status: " + completedOrder.getOrder().getOrderstatus());
                deliveredOrders.add(completedOrder);
                serialNumber++;
            }
        }

        if (deliveredOrders.isEmpty()) {
            System.out.println("No delivered orders available for review.");
            return;
        }

        // Ask the user to choose a completed order to review
        System.out.print("Enter the serial number of the delivered order you want to review: ");
        int choice = input.nextInt();
        input.nextLine(); // Consume newline

        if (choice < 1 || choice > deliveredOrders.size()) {
            System.out.println("Invalid choice!");
            return;
        }

        CompletedOrder selectedOrder = deliveredOrders.get(choice - 1);

        // Display items within the selected order for individual review
        List<CustomerFoodItems> itemsInOrder = selectedOrder.getOrder().getItems();
        if (itemsInOrder == null || itemsInOrder.isEmpty()) {
            System.out.println("No items found in this order for review.");
            return;
        }

        System.out.println("Items in selected order:");
        int itemNumber = 1;
        for (CustomerFoodItems item : itemsInOrder) {
            System.out.println(itemNumber + ". Food name: " + item.getName() +
                    ", Price: Rs " + item.getPrice() +
                    ", Quantity: " + item.getQuantity());
            itemNumber++;
        }

        // Ask user to choose an item to review
        System.out.print("Enter the item number you want to review: ");
        int itemChoice = input.nextInt();
        input.nextLine(); // Consume newline

        if (itemChoice < 1 || itemChoice > itemsInOrder.size()) {
            System.out.println("Invalid item choice!");
            return;
        }

        CustomerFoodItems selectedItem = itemsInOrder.get(itemChoice - 1);

        // Proceed with review type selection
        System.out.println("Would you like to leave a (1) rating or (2) textual review?");
        int reviewChoice = input.nextInt();
        input.nextLine(); // Consume the newline

        Review<?> review = null;

        switch (reviewChoice) {
            case 1:
                System.out.print("Enter a rating from 1 to 5: ");
                int rating = input.nextInt();
                input.nextLine();
                if (rating < 1 || rating > 5) {
                    System.out.println("Invalid rating! Please provide a rating between 1 and 5.");
                    return;
                }
                review = new Review<>(rating);
                break;

            case 2:
                System.out.print("Enter your textual review: ");
                String feedback = input.nextLine();
                review = new Review<>(feedback);
                break;

            default:
                System.out.println("Invalid choice! Please select either 1 or 2.");
                return;
        }

        // Add the review for the selected item in the order feedback list
        Review.itemFeedback.computeIfAbsent(selectedItem, k -> new ArrayList<>()).add(review);
        System.out.println("Your review for the item has been submitted successfully!");

        // Display the review for confirmation
        review.displayReview();

        // Prompt the user to reorder the item if they wish
        System.out.print("Would you like to reorder this item? (yes/no): ");
        String reorderChoice = input.nextLine();

        if ("yes".equalsIgnoreCase(reorderChoice)) {
            // Proceed to checkout the selected item as a new order
            this.getCart().add(selectedItem);
            System.out.println("The item has been added to your cart for reordering.");

            // Call checkout process for the customer
            checkoutprocess();
        } else {
            System.out.println("Reorder canceled.");
        }
    }

    // Method to view other customers' reviews
    public void viewOtherReviews() {
        System.out.println("Viewing all available reviews:");

        // Check if there are any reviews in both orderFeedback and itemFeedback
        if (Review.orderFeedback.isEmpty() && Review.itemFeedback.isEmpty()) {
            System.out.println("No reviews available to display.");
            return;
        }

        // Display reviews for each completed order
        if (!Review.orderFeedback.isEmpty()) {
            System.out.println("Completed Order Reviews:");
            for (Map.Entry<CompletedOrder, List<Review<?>>> entry : Review.orderFeedback.entrySet()) {
                CompletedOrder completedOrder = entry.getKey();
                List<Review<?>> reviews = entry.getValue();

                System.out.println("Order Date: " + completedOrder.getOrder().getOrderdate() +
                        ", Status: " + completedOrder.getOrder().getOrderstatus());

                // Display each review for the current completed order
                for (Review<?> review : reviews) {
                    System.out.print(" - ");
                    review.displayReview();
                }
                System.out.println();
            }
        } else {
//            System.out.println("No completed order reviews available.");
        }

        // Display reviews for individual items
        if (!Review.itemFeedback.isEmpty()) {
            System.out.println("Item Reviews:");
            for (Map.Entry<CustomerFoodItems, List<Review<?>>> entry : Review.itemFeedback.entrySet()) {
                CustomerFoodItems item = entry.getKey();
                List<Review<?>> reviews = entry.getValue();

                System.out.println("Item: " + item.getName() + ", Price: Rs " + item.getPrice());

                // Display each review for the current item
                for (Review<?> review : reviews) {
                    System.out.print(" - ");
                    review.displayReview();
                }
                System.out.println();
            }
        } else {
            System.out.println("No item reviews available.");
        }
    }




}
