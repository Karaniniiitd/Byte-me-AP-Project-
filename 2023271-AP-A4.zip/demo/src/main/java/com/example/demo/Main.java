package com.example.demo;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
public class Main {
    static boolean exit=false;
    public static void main(String[] args) {
        // creating admin
        Admin admin=new Admin("admin@2008","2008");
        admin.saveUserToFile(admin.emailid, admin.password, "Admin");

        //creating Food items objects
        FoodItems f1=new FoodItems(100,"Red Sauce Pasta","Pasta",100);
        FoodItems f2=new FoodItems(70,"Veg Steam Momo","Momo",100);
        FoodItems f3 = new FoodItems(80, "Paneer Tikka", "Appetizer", 50);
        FoodItems f4 = new FoodItems(120, "Margherita Pizza", "Pizza", 30);
        FoodItems f5 = new FoodItems(150, "Chicken Biryani", "Main Course", 70);
        FoodItems f6 = new FoodItems(60, "Chocolate Brownie", "Dessert", 40);
        FoodItems f7 = new FoodItems(50, "French Fries", "Snack", 100);
        FoodItems f8 = new FoodItems(90, "Mushroom Soup", "Soup", 20);
        FoodItems f9 = new FoodItems(110, "Butter Naan", "Bread", 0);
        FoodItems f10 = new FoodItems(130, "Pasta Alfredo", "Pasta", 80);
        //creating customers
        Customer c1 =new Customer("karan@2005","2005",false);
        c1.saveUserToFile(c1.emailid, c1.password, "Customer");
        Customer c2 =new Customer("kashish@2006","2006",false);
        c2.saveUserToFile(c2.emailid, c2.password, "Customer");
        Customer c3 =new Customer("smriti@2007","2007",false);
        c3.saveUserToFile(c3.emailid, c3.password, "Customer");
        Customer c4 =new Customer("vaibhav@2008","2008",false);
        c4.saveUserToFile(c4.emailid, c4.password, "Customer");
        Scanner input=new Scanner(System.in);
        while(!exit){
            System.out.println("Please choose an option");
            System.out.println("1. Login");
            System.out.println("2. Sign up");
            System.out.println("3. Exit");
            int choice=input.nextInt();
            input.nextLine();
            switch(choice){
                case 1: //Login
                    try {
                        Users user=login(input);
                        handleUserActions(user,input);
                    }
                    catch(InvalidLoginException e){
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    Users user=new Users("","");
                    user.signup();
                    break;
                case 3:
                    exit=true;
                    System.out.println("Exiting the application...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again!");
            }
        }



    }
    public static Users login(Scanner input) throws InvalidLoginException{
        System.out.println("Select your role:");
        System.out.println("1. Admin");
        System.out.println("2. Customer");
        int choice=input.nextInt();
        input.nextLine();
        System.out.println("Enter your email address:");
        String email=input.nextLine();
        System.out.println("Enter your password:");
        String password=input.nextLine();
        Users user=null;
        if(user==null){
            for(Customer customer:Customer.CustomersList){
                if(customer.getEmailid().equals(email)&&customer.getPassword().equals(password)){
                    user=customer;
                    break;
                }
            }
        }
        if(user==null){
            for(Admin admin:Admin.adminList){
                if(admin.getEmailid().equals(email)&&admin.getPassword().equals(password)){
                    user=admin;
                    break;
                }
            }
        }
        if(user==null){
            throw new InvalidLoginException("Invalid login");
        }
        return user;
    }
    public static void handleUserActions(Users user,Scanner input){
        if(user!=null){
            System.out.println("You are logged in as "+user.getEmailid()+". What would you like to do?");
            boolean loggedIn=true;
            while(loggedIn&&!Main.exit){
                if(user instanceof Admin){
                    System.out.println("1. Add Food Items");
                    System.out.println("2. Remove Food Items");
                    System.out.println("3. Update Existing Food Items");
                    System.out.println("4. View Pending Orders");
                    System.out.println("5. Update Order Status");
                    System.out.println("6. Process Refund");
                    System.out.println("7. Daily Sales Reports");
                    System.out.println("8. View all Food items");
                    System.out.println("9. Handle Special Requests");
                    System.out.println("10. Enter GUI mode");
                    System.out.println("11. Logout");
                    System.out.println("12. Exit the application");
                    int choice=input.nextInt();
                    input.nextLine();
                    Admin admin=(Admin)user;
                    switch(choice){
                        case 1:
                            admin.addnewitems();
                            break;
                        case 2:
                            admin.removeOrRestockItems();
                            break;
                        case 3:
                            admin.updateexistingitems();
                            break;
                        case 4:
                            admin.viewpendingorder();
                            break;
                        case 5:
                            admin.updateorderstatus();
                            break;
                        case 6:
                            admin.processrefund();
                            break;
                        case 7:
                            admin.dailysalesreport();
                            break;
                        case 8:
                            admin.viewitems();
                            break;
                        case 9:
                            admin.handlespecialrequest();
                            break;
                        case 10:
                            admin. EnterGUIMode();
                        case 11:
                            admin.logout();
                            loggedIn=false;
                            break;
                        case 12:
                            loggedIn=false;
                            Main.exit=true;
                            break;
                        default:
                            System.out.println("Invalid option. Please try again!");
                    }
                }
                else if(user instanceof Customer){
                    System.out.println("1. Be a VIP customer");
                    System.out.println("2. View Items");
                    System.out.println("3. Search Items");
                    System.out.println("4. Filter By Category");
                    System.out.println("5. Sort By Prices");
                    System.out.println("6. Add Items");
                    System.out.println("7. Modify Quantity");
                    System.out.println("8. View Cart");
                    System.out.println("9. Remove Items from Cart");
                    System.out.println("10. View Total Bill");
                    System.out.println("11. CheckOut Process");
                    System.out.println("12. View Order Status");
                    System.out.println("13. Cancel Order");
                    System.out.println("14. View Order History");
                    System.out.println("15. Provide Review");
                    System.out.println("16. View other Review");
                    System.out.println("17. Enter GUI mode");
                    System.out.println("18. Logout");
                    System.out.println("19. Exit the application");
                    int choice=input.nextInt();
                    input.nextLine();
                    Customer customer=(Customer)user;
                    switch(choice){
                        case 1:
                            customer.beingVIP();
                            break;
                        case 2:
                            customer.viewitems();
                            break;
                        case 3:
                            customer.searchitems();
                            break;
                        case 4:
                            customer.filterbycategory();
                            break;
                        case 5:
                            customer.sortbyprices();
                            break;
                        case 6:
                            customer.additems();
                            break;
                        case 7:
                            customer.modifyquantity();
                            break;
                        case 8:
                            customer.viewcart();
                            break;
                        case 9:
                            customer.removeitems();
                            break;
                        case 10:
                            customer.viewtotal();
                            break;
                        case 11:
                            customer.checkoutprocess();
                            break;
                        case 12:
                            customer.vieworderstatus();
                            break;
                        case 13:
                            customer.cancelorder();
                            break;
                        case 14:
                            customer.viewyourorderhistory();
                            break;
                        case 15:
                            customer.provideReview();
                            break;
                        case 16:
                            customer.viewOtherReviews();
                            break;
                        case 17:
                            customer.EnterGUIMode();
                            break;
                        case 18:
                            customer.logout();
                            loggedIn=false;

                            break;
                        case 19:
                            loggedIn=false;
                            Main.exit=true;
                            break;
                        default:
                            System.out.println("Invalid option. Please try again!");

                    }

                }
                else{
                    System.out.println("1. Logout");
                    System.out.println("2. Exit application");
                    int loggedInchoice=input.nextInt();
                    input.nextLine();
                    if(loggedInchoice==1){
                        user.logout();
                        loggedIn=false;
                    }else if(loggedInchoice==2){
                        loggedIn=false;
                        Main.exit=true;
                    }
                    else{
                        System.out.println("Invalid option. Please try again!");
                    }
                }
            }
        }

    }
}
