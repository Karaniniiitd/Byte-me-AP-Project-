package com.example.demo;

import java.io.*;
import java.util.Scanner;

public class Users {
    String emailid;
    String password;
    public Users(String emailid, String password) {
        this.emailid = emailid;
        this.password = password;
    }
    public String getEmailid() {
        return emailid;
    }
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public boolean login(){
        Scanner input = new Scanner(System.in);
        try{
            System.out.println("Enter your email id");
            String emailid = input.nextLine();
            if (!emailid.equals(this.emailid)){
                throw new InvalidLoginException("Invalid emaiL ID!");
            }
            System.out.println("Enter your password");
            String password = input.nextLine();
            if(!password.equals(this.password)){
                throw new InvalidLoginException("Invalid password!");
            }
            System.out.println("Login successful! Welcome " + this.emailid);
            return true;

        }
        catch(InvalidLoginException e){
            System.out.println(e.getMessage());
            return false;
        }

    }
    public void signup(){
        Scanner input = new Scanner(System.in);
        System.out.println("Choose your role : ");
        System.out.println("1. Admin");
        System.out.println("2. Customer");
        int role = input.nextInt();
        input.nextLine();
        switch(role){
            case 1:
                System.out.println("Enter your email id");
                this.setEmailid(input.nextLine());
                System.out.println("Enter your password");
                this.setPassword(input.nextLine());
                Admin admin = new Admin(this.emailid, this.password);
                saveUserToFile(this.emailid, this.password, "Admin");
                System.out.println("Admin Signup successful!");
                break;
            case 2:
                System.out.println("Enter your email id");
                this.setEmailid(input.nextLine());
                System.out.println("Enter your password");
                this.setPassword(input.nextLine());
                Customer customer=new Customer(this.emailid,this.password,false);
                saveUserToFile(this.emailid, this.password, "Customer");
                System.out.println("Customer Signup successful!");
                break;
            default:
                System.out.println("Invalid role!");
        }
    }
    public void logout(){
        System.out.println("User "+this.emailid+" has logged out!");
    }
    // Save the new user's data to "registered.txt"
    public void saveUserToFile(String email, String password, String role) {
        BufferedWriter writer = null;
        try {
            // Open the file in append mode
            writer = new BufferedWriter(new FileWriter("registered.txt", true));
            // Write the user's details in the format: email, password, role
            writer.write(email + "," + password + "," + role);
            writer.newLine(); // Add a newline after each user's data
//            System.out.println("User data saved to registered.txt successfully!");
        } catch (IOException e) {
            System.out.println("Error saving user data to file: " + e.getMessage());
        } finally {
            try {
                if (writer != null) {
                    writer.close(); // Close the writer
                }
            } catch (IOException e) {
                System.out.println("Error closing writer: " + e.getMessage());
            }
        }
    }

}
