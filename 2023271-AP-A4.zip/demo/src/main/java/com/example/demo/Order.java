package com.example.demo;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Order extends Customer{
    private String orderstatus;
    private long orderID;
    private LocalDate orderdate;
    public static Map<Order,Customer>Orderlist=new HashMap<Order,Customer>();
    private List<CustomerFoodItems> items;

    public Order(String emailid, String password, boolean VipStatus,String orderstatus, LocalDate orderdate, List<CustomerFoodItems> items,long orderID) {
        super(emailid, password, VipStatus);
        this.orderstatus=orderstatus;
        this.orderdate=LocalDate.now();
        this.items=items;
        this.orderID=orderID;
    }
    public String getOrderstatus() {
        return orderstatus;
    }
    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }
    public LocalDate getOrderdate() {
        return orderdate;
    }
    public void setOrderdate(LocalDate orderdate) {
        this.orderdate = orderdate;
    }
    public List<CustomerFoodItems> getItems() {
        return items;
    }
    public void setItems(List<CustomerFoodItems> items) {
        this.items = items;
    }
    public long getOrderID() {
        return orderID;
    }
    public void setOrderID(long orderID) {
        this.orderID = orderID;
    }

}
