package com.example.demo;
import java.util.*;
public class SpecialRequest extends Customer{
    String specialrequsetstatus;
    public static Map<Customer,SpecialRequest> specialRequestMap=new HashMap<>();
    public SpecialRequest(String emailid, String password, boolean VipStatus,String specialrequsetstatus) {
        super(emailid, password, VipStatus);
        this.specialrequsetstatus = specialrequsetstatus;
        specialRequestMap.put(this,this);
    }
    public String getSpecialrequsetstatus() {
        return specialrequsetstatus;
    }
    public void setSpecialrequsetstatus(String specialrequsetstatus) {
        this.specialrequsetstatus = specialrequsetstatus;
    }
}
