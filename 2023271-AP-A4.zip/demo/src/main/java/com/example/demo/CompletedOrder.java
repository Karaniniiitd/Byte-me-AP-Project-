package com.example.demo;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CompletedOrder {
    private Order order; // Reference to the order
    private Customer customer; // Reference to the customer
    private LocalDate orderDate; // Date of the order delivery

    public CompletedOrder(Order order, Customer customer) {
        this.order = order;
        this.customer = customer;
        this.orderDate = LocalDate.now(); // Or set it to the order date if needed
    }

    // Getters for the completed order details
    public Order getOrder() {
        return order;
    }

    public Customer getCustomer() {
        return customer;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }
}

// The class to store all completed orders
class CompletedOrders {
    public static List<CompletedOrder> completedOrderList = new ArrayList<>();

    public static void addCompletedOrder(Order order, Customer customer) {
        completedOrderList.add(new CompletedOrder(order, customer));
    }
}
