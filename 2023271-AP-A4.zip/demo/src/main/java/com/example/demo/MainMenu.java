package com.example.demo;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainMenu extends Application {
    Stage window;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        window = stage;
        window.setOnCloseRequest(e->{
            e.consume();
            click();

        });
        // Main menu layout
        Button pendingOrdersButton = new Button("View Pending Orders");
        pendingOrdersButton.setOnAction(e -> openPendingOrders());

        Button viewMenuButton = new Button("View Menu");
        viewMenuButton.setOnAction(e -> openFoodItemsMenu());

        VBox mainMenuLayout = new VBox(20); // VBox with spacing of 20
        mainMenuLayout.setAlignment(Pos.CENTER); // Center-align the VBox
        mainMenuLayout.setStyle("-fx-padding: 20;"); // Add some padding
        mainMenuLayout.getChildren().addAll(pendingOrdersButton, viewMenuButton);

        Scene mainMenuScene = new Scene(mainMenuLayout, 300, 200);

        // Setup window
        window.setTitle("Main Menu");
        window.setScene(mainMenuScene);
        window.show();
    }

    private void openPendingOrders() {
        try {
            // Start OrderList GUI
            new OrderList().start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openFoodItemsMenu() {
        try {
            // Start FoodItemsGUI
            new FoodItemsGUI().start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void click(){
        boolean ans=ConfirmationBox.display("Confirm");
        if (ans){
            window.close();
        }
    }
    public static void display() {
        launch();
    }
}
