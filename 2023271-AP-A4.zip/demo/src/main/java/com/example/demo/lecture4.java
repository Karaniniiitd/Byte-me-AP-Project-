package com.example.demo;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.awt.*;

public class lecture4 extends Application {
    Stage window;
    Scene scene1,scene2;
    public static void main(String[] args) {
        launch(args);



    }

    @Override
    public void start(Stage stage) throws Exception {
        window=stage;
        Button button1 = new Button("Button 1");
        button1.setOnAction(e->window.setScene(scene2));
        StackPane root = new StackPane();
        root.getChildren().add(button1);
        scene1=new Scene(root, 300, 250);
        Button button2 = new Button("Button 2");
        button2.setOnAction(e->window.setScene(scene1));
        StackPane stackPane = new StackPane();
        stackPane.getChildren().add(button2);
        scene2=new Scene(stackPane, 300, 250);
        window.setTitle("Switch scene");
        window.setScene(scene1);
        window.show();






    }
}
