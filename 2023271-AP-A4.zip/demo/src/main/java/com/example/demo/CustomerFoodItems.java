package com.example.demo;
import java.util.ArrayList;
import java.util.List;

public class CustomerFoodItems extends FoodItems{
    private int quantity;
    String specialrequest;
    boolean checkedout;
    public static List<CustomerFoodItems> customerFoodItemsList = new ArrayList<CustomerFoodItems>();
    public CustomerFoodItems(int price, String name, String category, int availability,int quantity,String specialrequest,boolean checkedout) {
        super(price, name, category, availability);
        this.quantity = quantity;
        this.specialrequest = specialrequest;
        this.checkedout = false;
        customerFoodItemsList.add(this);
    }
    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public String getSpecialrequest() {
        return specialrequest;
    }
    public void setSpecialrequest(String specialrequest) {
        this.specialrequest = specialrequest;
    }
    public boolean isCheckedOut() {
        return checkedout;
    }
    public void setCheckedOut(boolean checkedout) {
        this.checkedout = checkedout;
    }

}
