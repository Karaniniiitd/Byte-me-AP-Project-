package com.example.demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;

public class OrderList extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Order List Viewer");

        // Layout
        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-background-color: #f0f0f0;");
        ScrollPane scrollPane = new ScrollPane(layout);
        scrollPane.setFitToWidth(true);

        // File reading
        File file = new File("orders.txt");
        if (!file.exists()) {
            Label noOrdersLabel = new Label("No orders found. Please make sure the orders.txt file exists.");
            layout.getChildren().add(noOrdersLabel);
        } else {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                StringBuilder orderDetails = new StringBuilder();
                VBox orderBox = null;
                Label orderIdLabel = null; // To hold the Order ID

                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("Order ID:")) {
                        // Display the previous order details if we reach a new one
                        if (orderBox != null) {
                            layout.getChildren().add(orderBox);
                        }

                        // Create a new container for the current order
                        orderBox = new VBox(5);
                        orderBox.setStyle("-fx-border-color: #ccc; -fx-border-radius: 5; -fx-padding: 10; -fx-background-color: #fff;");

                        // Add the Order ID
                        orderIdLabel = new Label(line); // Display "Order ID: ..."
                        orderIdLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #2a6cc8;");
                        orderBox.getChildren().add(orderIdLabel);

                        // Reset order details for this new order
                        orderDetails = new StringBuilder();
                    } else if (line.startsWith("Order Details:")) {
                        Label header = new Label(line); // Display "Order Details:"
                        header.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
                        orderBox.getChildren().add(header);
                    } else if (line.equals("------")) {
                        // End of order; display the details
                        if (orderBox != null) {
                            Label orderLabel = new Label(orderDetails.toString());
                            orderBox.getChildren().add(orderLabel);
                        }
                    } else {
                        // Collect order details
                        orderDetails.append(line).append("\n");
                    }
                }

                // Add the last order box
                if (orderBox != null) {
                    layout.getChildren().add(orderBox);
                }
            } catch (IOException e) {
                Label errorLabel = new Label("Error reading orders.txt: " + e.getMessage());
                layout.getChildren().add(errorLabel);
            }
        }

        // "Go to Menu" button
        Button goToMenuButton = new Button("Go to Menu");
        goToMenuButton.setStyle("-fx-font-size: 14; -fx-padding: 5 15 5 15;"); // Style the button
        goToMenuButton.setOnAction(e -> {
            try {
                // Switch to FoodItemsGUI
                new FoodItemsGUI().start(primaryStage); // Switch GUI on the same stage
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // Layout setup using BorderPane
        BorderPane layoutWithButton = new BorderPane();
        layoutWithButton.setCenter(scrollPane); // Add the scrollable content in the center
        layoutWithButton.setBottom(goToMenuButton); // Add the button at the bottom
        BorderPane.setAlignment(goToMenuButton, Pos.BOTTOM_RIGHT); // Align button to bottom-right
        BorderPane.setMargin(goToMenuButton, new Insets(10)); // Add margin for spacing

        // Scene
        Scene scene = new Scene(layoutWithButton, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
