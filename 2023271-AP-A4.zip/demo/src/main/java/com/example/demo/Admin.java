package com.example.demo;

import javax.swing.event.ListDataEvent;
import java.io.*;
import java.time.LocalDate;
import java.util.*;


public class Admin extends Users{
    public static List<Admin>adminList=new ArrayList<>();
    public Admin(String emailid, String password) {

        super(emailid, password);
        adminList.add(this);
    }
    public void viewitems(){
        for(FoodItems foodItems:FoodItems.FoodItemsList){
            System.out.println("-------------------");
            System.out.println("Food name : "+foodItems.getName());
            System.out.println("Food price : "+foodItems.getPrice());
            System.out.println("Food category : "+foodItems.getCategory());
            System.out.println("Food Availability : "+foodItems.getAvailability());
            System.out.println("-------------------");
        }
    }
    public  void EnterGUIMode(){
        MainMenu.display(); //
    }
    public void addnewitems(){
        Scanner input = new Scanner(System.in);
        System.out.println("Give food name : ");
        String foodname=input.nextLine();
        System.out.println("Set food price");
        int price=input.nextInt();
        input.nextLine();
        System.out.println("Set food Category");
        String Category=input.nextLine();
        System.out.println("Set food Availability");
        int availability=input.nextInt();
        FoodItems foodItems=new FoodItems(price,foodname,Category,availability);
        System.out.println(" Food Item added successfully!");
        System.out.println("-------------------");
        System.out.println("Food name : "+foodItems.getName());
        System.out.println("Food price : "+foodItems.getPrice());
        System.out.println("Food category : "+foodItems.getCategory());
        System.out.println("Food Availability : "+foodItems.getAvailability());
        System.out.println("-------------------");



    }
    public void updateexistingitems(){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the food item name to update:");
        String foodname = input.nextLine();

        // Assuming we have a list of food items or some way to find an item by name
        FoodItems itemToUpdate = findFoodItemByName(foodname); // Placeholder for search function

        if (itemToUpdate == null) {
            System.out.println("Food item not found!");
            return;
        }

        System.out.println("What would you like to update?");
        System.out.println("1. Price");
        System.out.println("2. Category");
        System.out.println("3. Availability");
        System.out.print("Choose an option (1-3): ");
        int choice = input.nextInt();
        input.nextLine(); // Consume the newline

        switch (choice) {
            case 1:
                System.out.print("Enter new price: ");
                int newPrice = input.nextInt();
                itemToUpdate.setPrice(newPrice);
                System.out.println("Price updated successfully.");
                break;
            case 2:
                System.out.print("Enter new category: ");
                String newCategory = input.nextLine();
                itemToUpdate.setCategory(newCategory);
                System.out.println("Category updated successfully.");
                break;
            case 3:
                System.out.print("Enter new availability: ");
                int newAvailability = input.nextInt();
                itemToUpdate.setAvailability(newAvailability);
                System.out.println("Availability updated successfully.");
                break;
            default:
                System.out.println("Invalid choice!");
                break;
        }
    }

    public void removeOrRestockItems() {
        Scanner input = new Scanner(System.in);

        // Prompt the admin for an item name to restock or remove
        System.out.print("Enter the name of the item you want to restock or remove: ");
        String itemName = input.nextLine();

        // Find the item in the FoodItemsList
        FoodItems targetItem = null;
        for (FoodItems item : FoodItems.FoodItemsList) {
            if (item.getName().equalsIgnoreCase(itemName)) {
                targetItem = item;
                break;
            }
        }

        // Check if the item was found
        if (targetItem != null) {
            System.out.println("Item: " + targetItem.getName() + " (Price: " + targetItem.getPrice() + ", Availability: " + targetItem.getAvailability() + ")");

            // Ask admin whether to restock or remove
            System.out.print("Do you want to restock or remove this item? (restock/remove): ");
            String choice = input.nextLine();

            if (choice.equalsIgnoreCase("restock")) {
                System.out.print("Enter new availability: ");
                int newAvailability = input.nextInt();
                input.nextLine(); // Consume newline

                // Update item availability
                targetItem.setAvailability(newAvailability);
                System.out.println("Availability updated successfully.");
            } else if (choice.equalsIgnoreCase("remove")) {
                // Remove item from FoodItemsList
                FoodItems.FoodItemsList.remove(targetItem);
                System.out.println("Item removed successfully.");

                // Check orders containing removed item and mark them as "Denied"
                for (Map.Entry<Order, Customer> entry : Order.Orderlist.entrySet()) {
                    Order order = entry.getKey();
                    Customer customer = entry.getValue();

                    // Check if the customer's cart contains the removed item
                    boolean itemFoundInOrder = false;
                    for (CustomerFoodItems cartItem : customer.getCart()) {
                        if (cartItem.getName().equalsIgnoreCase(targetItem.getName())) {
                            itemFoundInOrder = true;
                            break;
                        }
                    }

                    // If the order contains the removed item, mark its status as "Denied"
                    if (itemFoundInOrder) {
                        order.setOrderstatus("Denied");
//                        updateOrderToFile(order,order.);
                        customer.getCart().clear();
                        System.out.println("Order for customer " + customer.getEmailid() + " has been marked as 'Denied' due to removed item.");
                        System.out.println("Customer's cart has been cleared.");
                        CompletedOrders.addCompletedOrder(order, customer);
                    }
                }
            } else {
                System.out.println("Invalid choice. Action aborted.");
            }
        } else {
            System.out.println("Item not found in the inventory.");
        }
    }





    // Placeholder method to find a food item by its name
    private FoodItems findFoodItemByName(String name) {
        for(FoodItems f: FoodItems.FoodItemsList){
            if(f.getName().equals(name)){
                return f;
            }
        }
        return null;
    }
    public void viewpendingorder() {
        System.out.println("Pending Orders:");

        List<Map.Entry<Order, Customer>> vipOrders = new ArrayList<>();
        List<Map.Entry<Order, Customer>> regularOrders = new ArrayList<>();

        // Separate orders into VIP and regular based on the customer's VIP status
        for (Map.Entry<Order, Customer> entry : Order.Orderlist.entrySet()) {
            Order order = entry.getKey();
            Customer customer = entry.getValue();

            // Check if the order status is "pending"
            if ("pending".equalsIgnoreCase(order.getOrderstatus())) {
                if (customer.getVipStatus()) {
                    vipOrders.add(entry);
                } else {
                    regularOrders.add(entry);
                }
            }
        }

        boolean hasPendingOrders = !vipOrders.isEmpty() || !regularOrders.isEmpty();

        // Display VIP orders first
        if (!vipOrders.isEmpty()) {
            System.out.println("VIP Customers' Pending Orders:");
            for (Map.Entry<Order, Customer> entry : vipOrders) {
                Order order = entry.getKey();
                Customer customer = entry.getValue();

                // Display order details and customer details
                System.out.println("Order Details:");
                System.out.println("Customer Email: " + customer.getEmailid());
                System.out.println("Customer VIP Status: " + customer.getVipStatus());
                System.out.println("Order Status: " + order.getOrderstatus());

                // Display each item in the customer's cart
                System.out.println("Customer Cart Details:");
                for (CustomerFoodItems item : customer.getCart()) {
                    System.out.println("  - Food Name: " + item.getName());
                    System.out.println("    Price: " + item.getPrice());
                    System.out.println("    Category: " + item.getCategory());
                    System.out.println("    Availability: " + item.getAvailability());
                    System.out.println("    Quantity: " + item.getQuantity());
                }
                System.out.println("------");
            }
        } else {
            System.out.println("No VIP customers have pending orders.");
        }

        // Display regular customers' pending orders
        if (!regularOrders.isEmpty()) {
            System.out.println("Regular Customers' Pending Orders:");
            for (Map.Entry<Order, Customer> entry : regularOrders) {
                Order order = entry.getKey();
                Customer customer = entry.getValue();

                // Display order details and customer details
                System.out.println("Order Details:");
                System.out.println("Customer Email: " + customer.getEmailid());
                System.out.println("Customer VIP Status: " + customer.getVipStatus());
                System.out.println("Order Status: " + order.getOrderstatus());

                // Display each item in the customer's cart
                System.out.println("Customer Cart Details:");
                for (CustomerFoodItems item : customer.getCart()) {
                    System.out.println("  - Food Name: " + item.getName());
                    System.out.println("    Price: " + item.getPrice());
                    System.out.println("    Category: " + item.getCategory());
                    System.out.println("    Availability: " + item.getAvailability());
                    System.out.println("    Quantity: " + item.getQuantity());
                }
                System.out.println("------");
            }
        } else {
            System.out.println("No regular customers have pending orders.");
        }

        // If there are no pending orders at all, let the admin know
        if (!hasPendingOrders) {
            System.out.println("No pending orders found.");
        }
    }


    public void updateorderstatus() {
        Scanner input = new Scanner(System.in);
        System.out.println("Updating Order Status:");

        // Separate VIP and regular orders
        List<Order> vipOrders = new ArrayList<>();
        List<Order> regularOrders = new ArrayList<>();

        for (Map.Entry<Order, Customer> entry : Order.Orderlist.entrySet()) {
            Order order = entry.getKey();
            Customer customer = entry.getValue();

            if (customer.getVipStatus()) {
                vipOrders.add(order);
            } else {
                regularOrders.add(order);
            }
        }

        // Update VIP orders first
        if (!vipOrders.isEmpty()) {
            System.out.println("Updating VIP Customer Orders:");
            for (Order order : vipOrders) {
                System.out.println("Order for VIP Customer - Current Status: " + order.getOrderstatus());
                System.out.println("Choose new status for this order:");
                System.out.println("1. Order Received");
                System.out.println("2. Preparing");
                System.out.println("3. Out for Delivery");
                System.out.println("4. Delivered");
                System.out.println("5. Cancelled");
                System.out.print("Enter choice (1-5): ");

                int choice = input.nextInt();
                input.nextLine(); // Consume newline

                String newStatus;
                switch (choice) {
                    case 1:
                        newStatus = "Order Received";
                        break;
                    case 2:
                        newStatus = "Preparing";
                        break;
                    case 3:
                        newStatus = "Out for Delivery";
                        break;
                    case 4:
                        newStatus = "Delivered";
                        break;
                    case 5:
                        newStatus = "Cancelled";
                        break;
                    default:
                        System.out.println("Invalid choice!");
                        continue;
                }

                // Update order status
                order.setOrderstatus(newStatus);
                System.out.println("Order status updated to: " + newStatus);

                // Clear cart if status is "Delivered" or "Denied"
                if (newStatus.equals("Delivered")) {
                    Customer customer = Order.Orderlist.get(order);
                    if (customer != null) {
                        for (CustomerFoodItems item : customer.getCart()) {
                            item.setCheckedOut(false);
                        }
                        CompletedOrders.addCompletedOrder(order,customer);
                        customer.getCart().clear(); // Clear the customer's cart
                        System.out.println("Customer's cart has been cleared.");

                        Order.Orderlist.remove(order);
                    }
                } else if (newStatus.equals("Cancelled")) {
                    System.out.println("PROCESS REFUND : ");
                    processrefund();

                }
            }
        } else {
            System.out.println("No VIP orders to update.");
        }

        // Update regular orders next
        if (!regularOrders.isEmpty()) {
            System.out.println("Updating Regular Customer Orders:");
            for (Order order : regularOrders) {
                System.out.println("Order for Regular Customer - Current Status: " + order.getOrderstatus());
                System.out.println("Choose new status for this order:");
                System.out.println("1. Order Received");
                System.out.println("2. Preparing");
                System.out.println("3. Out for Delivery");
                System.out.println("4. Delivered");
                System.out.println("5. Cancelled");
                System.out.print("Enter choice (1-5): ");

                int choice = input.nextInt();
                input.nextLine(); // Consume newline

                String newStatus;
                switch (choice) {
                    case 1:
                        newStatus = "Order Received";
                        break;
                    case 2:
                        newStatus = "Preparing";
                        break;
                    case 3:
                        newStatus = "Out for Delivery";
                        break;
                    case 4:
                        newStatus = "Delivered";
                        break;
                    case 5:
                        newStatus = "Cancelled";
                        break;
                    default:
                        System.out.println("Invalid choice!");
                        continue;
                }

                // Update order status
                order.setOrderstatus(newStatus);
                System.out.println("Order status updated to: " + newStatus);

                // Clear cart if status is "Delivered" or "Denied"
                // Clear cart if status is "Delivered" or "Denied"
                if (newStatus.equals("Delivered")) {
                    Customer customer = Order.Orderlist.get(order);
                    if (customer != null) {
                        for (CustomerFoodItems item : customer.getCart()) {
                            item.setCheckedOut(false);
                        }
                        CompletedOrders.addCompletedOrder(order,customer);
                        customer.getCart().clear(); // Clear the customer's cart
                        System.out.println("Customer's cart has been cleared.");

                        Order.Orderlist.remove(order);
                    }
                }
                else if (newStatus.equals("Cancelled")) {
                    System.out.println("PROCESS REFUND : ");
                    processrefund();

                }

            }
        } else {
            System.out.println("No regular orders to update.");
        }
        saveAllOrdersToFile();
    }

    public void processrefund() {
        boolean refundProcessed = false;

        // Separate lists for VIP and regular customer refunds
        List<Map.Entry<Order, Customer>> vipOrders = new ArrayList<>();
        List<Map.Entry<Order, Customer>> regularOrders = new ArrayList<>();

        // Loop through the Orderlist to find orders that belong to this customer
        Iterator<Map.Entry<Order, Customer>> iterator = Order.Orderlist.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<Order, Customer> entry = iterator.next();
            Order order = entry.getKey();
            Customer customer = entry.getValue();

            // Check if the order has been cancelled
            if ("Cancelled".equalsIgnoreCase(order.getOrderstatus())) {
                // Separate orders by VIP status
                if (customer.getVipStatus()) {
                    vipOrders.add(entry); // Add to VIP list
                } else {
                    regularOrders.add(entry); // Add to regular list
                }
            }
        }

        // Process VIP orders first
        if (!vipOrders.isEmpty()) {
            for (Map.Entry<Order, Customer> entry : vipOrders) {
                Customer customer = entry.getValue();
                Order order = entry.getKey();
                refundProcessed = true;
                System.out.println("Refunding VIP customer: " + customer.getEmailid());
                System.out.println("Order found with status 'Cancelled'. Processing refund...");

                // Set order status to "Denied" and add to completed orders
                order.setOrderstatus("Denied");
                customer.getCart().clear();
                System.out.println("Customer's cart has been cleared.");
                CompletedOrders.addCompletedOrder(order, customer);

                // Remove the order from the Orderlist
                iterator.remove();
                System.out.println("Your order has been successfully removed, and your refund is being processed.");
            }
        }

        // Process regular orders next
        if (!regularOrders.isEmpty()) {
            for (Map.Entry<Order, Customer> entry : regularOrders) {
                Customer customer = entry.getValue();
                Order order = entry.getKey();
                refundProcessed = true;
                System.out.println("Refunding regular customer: " + customer.getEmailid());
                System.out.println("Order found with status 'Cancelled'. Processing refund...");

                // Set order status to "Denied" and add to completed orders
                order.setOrderstatus("Denied");
                customer.getCart().clear();
                System.out.println("Customer's cart has been cleared.");
                CompletedOrders.addCompletedOrder(order, customer);

                // Remove the order from the Orderlist
                iterator.remove();
                System.out.println("Your order has been successfully removed, and your refund is being processed.");
            }
        }

        // If no cancelled orders were found for refund processing, notify them
        if (!refundProcessed) {
            System.out.println("No cancelled orders found for refund processing.");
        }
    }




    public void dailysalesreport() {
        // Initialize variables
        int totalSales = 0;
        int totalOrders = 0;
        Map<String, Integer> itemFrequency = new HashMap<>();

        // Get the current date to filter today's orders
        LocalDate today = LocalDate.now();

        // Iterate through all completed orders in the completedOrderList
        for (CompletedOrder completedOrder : CompletedOrders.completedOrderList) {
            Order order = completedOrder.getOrder();
            Customer customer = completedOrder.getCustomer();

            // Check if the order was delivered today
            if ("Delivered".equalsIgnoreCase(order.getOrderstatus()) && today.equals(order.getOrderdate())) {
                totalOrders++; // Increment the total orders count

                // Iterate through items directly from the completed order
                if (order.getItems() != null && !order.getItems().isEmpty()) {
                    for (CustomerFoodItems item : order.getItems()) {
                        // Add item cost to total sales
                        totalSales += item.getPrice() * item.getQuantity();

                        // Track the frequency of each item for popularity calculation
                        itemFrequency.put(item.getName(), itemFrequency.getOrDefault(item.getName(), 0) + item.getQuantity());
                    }
                }
            }
        }

        // Identify the most popular item by finding the item with the highest frequency
        String mostPopularItem = null;
        int highestFrequency = 0;
        for (Map.Entry<String, Integer> entry : itemFrequency.entrySet()) {
            if (entry.getValue() > highestFrequency) {
                highestFrequency = entry.getValue();
                mostPopularItem = entry.getKey();
            }
        }

        // Display the daily sales report
        System.out.println("Daily Sales Report:");
        System.out.println("Date: " + today);
        System.out.println("Total Sales: Rs " + totalSales);
        System.out.println("Total Orders: " + totalOrders);
        if (mostPopularItem != null) {
            System.out.println("Most Popular Item: " + mostPopularItem + " (ordered " + highestFrequency + " times)");
        } else {
            System.out.println("No items sold today.");
        }
    }

    public void handlespecialrequest() {
        System.out.println("Handling Special Requests:");

        // Lists to hold VIP and regular special requests
        List<SpecialRequest> vipRequests = new ArrayList<>();
        List<SpecialRequest> regularRequests = new ArrayList<>();

        // Separate the requests into VIP and regular, and filter out any null requests
        for (Map.Entry<Customer, SpecialRequest> entry : SpecialRequest.specialRequestMap.entrySet()) {
            Customer customer = entry.getKey();
            SpecialRequest request = entry.getValue();

            if (request != null) { // Only add non-null requests
                if (customer.getVipStatus()) {
                    vipRequests.add(request);
                } else {
                    regularRequests.add(request);
                }
            }
        }

        // Process VIP requests first
        if (!vipRequests.isEmpty()) {
            System.out.println("\n--- Processing VIP Special Requests ---");
            for (SpecialRequest request : vipRequests) {
                System.out.println("\nRequest from: " + request.getEmailid());
                System.out.println("Current Status: " + request.getSpecialrequsetstatus());

                // Set the status to "Approved" (or any other specific handling logic)
                request.setSpecialrequsetstatus("Approved");
                System.out.println("Status updated to: Approved");
            }
        } else {
            System.out.println("\nNo VIP special requests to process.");
        }

        // Process regular requests next
        if (!regularRequests.isEmpty()) {
            System.out.println("\n--- Processing Regular Special Requests ---");
            for (SpecialRequest request : regularRequests) {
                System.out.println("\nRequest from: " + request.getEmailid());
                System.out.println("Current Status: " + request.getSpecialrequsetstatus());

                // Set the status to "Approved"
                request.setSpecialrequsetstatus("Approved");
                System.out.println("Status updated to: Approved");
            }
        } else {
            System.out.println("\nNo regular special requests to process.");
        }
    }
    // Method to update the order file with current order details
    public void updateOrderToFile(Order order, String address) {
        File file = new File("orders.txt");

        // Read all lines into memory
        List<String> fileContent = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                fileContent.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }

        // Replace the old order details with updated ones
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            boolean orderFound = false;
            for (String line : fileContent) {
                if (line.contains("Order ID: " + order.getOrderID())) {
                    orderFound = true;
                    writer.write("Order ID: " + order.getOrderID());
                    writer.newLine();
                    writer.write("Order Details:");
                    writer.newLine();
                    writer.write("Customer Email: " + order.getEmailid());
                    writer.newLine();
                    writer.write("VIP Status: " + order.getVipStatus());
                    writer.newLine();
                    writer.write("Order Status: " + order.getOrderstatus()); // Updated status
                    writer.newLine();
                    writer.write("Order Date: " + order.getOrderdate());
                    writer.newLine();
                    writer.write("Delivery Address: " + address);
                    writer.newLine();
                    writer.write("Cart Details:");
                    writer.newLine();
                    for (CustomerFoodItems item : order.getCart()) {
                        writer.write("  - Food Name: " + item.getName());
                        writer.write(", Price: " + item.getPrice());
                        writer.write(", Category: " + item.getCategory());
                        writer.write(", Quantity: " + item.getQuantity());
                        writer.newLine();
                    }
                    writer.write("------");
                    writer.newLine();
                } else {
                    // Write the original lines for orders not matching the updated order
                    writer.write(line);
                    writer.newLine();
                }
            }

            if (!orderFound) {
                System.out.println("Order ID not found for update.");
            }
            writer.flush();
            System.out.println("Order details updated successfully.");
        } catch (IOException e) {
            System.out.println("Error saving updated order to file: " + e.getMessage());
        }
    }
    private void saveAllOrdersToFile() {
        File file = new File("orders.txt");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) { // Open file in overwrite mode
            for (Map.Entry<Order, Customer> entry : Order.Orderlist.entrySet()) {
                Order order = entry.getKey();
                Customer customer = entry.getValue();

                writer.write("Order ID: " + order.getOrderID());
                writer.newLine();
                writer.write("Order Details:");
                writer.newLine();
                writer.write("Customer Email: " + order.getEmailid());
                writer.newLine();
                writer.write("VIP Status: " + customer.getVipStatus());
                writer.newLine();
                writer.write("Order Status: " + order.getOrderstatus());
                writer.newLine();
                writer.write("Order Date: " + order.getOrderdate());
                writer.newLine();
//                writer.write("Delivery Address: " + order.getAddress());
//                writer.newLine();
                writer.write("Cart Details:");
                writer.newLine();
                for (CustomerFoodItems item : order.getCart()) {
                    writer.write("  - Food Name: " + item.getName());
                    writer.write(", Price: " + item.getPrice());
                    writer.write(", Category: " + item.getCategory());
                    writer.write(", Quantity: " + item.getQuantity());
                    writer.newLine();
                }
                writer.write("------");
                writer.newLine();
            }
            writer.flush();
            System.out.println("Orders saved to file successfully.");
        } catch (IOException e) {
            System.out.println("Error saving orders to file: " + e.getMessage());
        }
    }






}
