//package com.example.demo;
//
//import javafx.application.Application;
//import javafx.scene.Scene;
//import javafx.scene.layout.StackPane;
//import javafx.stage.Stage;
//
//public class MainApp extends Application {
//
//    private Stage window;
//
//    public static void main(String[] args) {
//        launch(args);
//    }
//
//    @Override
//    public void start(Stage primaryStage) {
//        window = primaryStage;
//        window.setTitle("Main Menu");
//
//        // Set initial scene (Main Menu)
//        MainMenu mainMenu = new MainMenu(window);
//        Scene mainMenuScene = mainMenu.createScene();
//        window.setScene(mainMenuScene);
//        window.show();
//    }
//
//    // Method to switch scenes
//    public void switchScene(Scene newScene) {
//        window.setScene(newScene);
//    }
//}
