package com.example.demo;

public interface User {
    public boolean login();
    public void logout();
    public void signup();
}
