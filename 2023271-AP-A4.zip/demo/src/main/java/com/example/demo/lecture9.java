package com.example.demo;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

import static javafx.application.Application.launch;

public class lecture9 extends Application {
    Stage window;
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage stage) throws Exception {
        window = stage;
        window.setTitle("Login");
        GridPane grip=new GridPane();
        grip.setPadding(new Insets(10,10,10,10));
        grip.setHgap(10);
        grip.setVgap(8);
        //name label
        Label label=new Label("Username");
        GridPane.setConstraints(label,0,0);
        //name input
        TextField tf=new TextField("Karan");
        GridPane.setConstraints(tf,1,0);

        //password label
        Label label1=new Label("Password");
        GridPane.setConstraints(label1,0,1);

        //password input
        TextField tf1=new TextField();
        tf1.setPromptText("Password");
        GridPane.setConstraints(tf1,1,1);
        Button login=new Button("Login");
        GridPane.setConstraints(login,1,2);
        grip.getChildren().addAll(label,tf,label1,tf1,login);
        Scene scene=new Scene(grip);
        window.setScene(scene);
        window.show();
        



    }
}
