package com.example.demo;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

import static javafx.application.Application.launch;

public class lecture6 extends Application {
    Stage window;
    Button button;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        window = stage;
        window.setTitle("Yo window");
        window.setOnCloseRequest(e->{
            e.consume();
            click();

        });
        button = new Button("Click Me");
        button.setOnAction(event -> click());
        StackPane root = new StackPane();
        root.getChildren().add(button);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root,300,250);
        window.setScene(scene);
        window.show();
    }
    public void click(){
        boolean ans=ConfirmationBox.display("Confirm");
        if (ans){
            window.close();
        }
    }
}
