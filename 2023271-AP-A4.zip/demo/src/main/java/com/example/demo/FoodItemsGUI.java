package com.example.demo;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FoodItemsGUI extends Application {

    TableView<FoodItems> table;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Available Food Items");

        // Name column
        TableColumn<FoodItems, String> nameCol = new TableColumn<>("Name");
        nameCol.setMinWidth(200);
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        // Price column
        TableColumn<FoodItems, Integer> priceCol = new TableColumn<>("Price");
        priceCol.setMinWidth(100);
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Category column
        TableColumn<FoodItems, String> categoryCol = new TableColumn<>("Category");
        categoryCol.setMinWidth(150);
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));

        // Availability column
        TableColumn<FoodItems, Integer> availabilityCol = new TableColumn<>("Availability");
        availabilityCol.setMinWidth(100);
        availabilityCol.setCellValueFactory(new PropertyValueFactory<>("availability"));

        // TableView setup
        table = new TableView<>();
        table.setItems(getFoodItems()); // Load food items from FoodItemsList
        table.getColumns().addAll(nameCol, priceCol, categoryCol, availabilityCol);

        // Table layout in a VBox
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(table);

        // "Go to Order List" button
        Button goToOrderListButton = new Button("Go to Order List");
        goToOrderListButton.setStyle("-fx-padding: 10; -fx-font-size: 14;");
        goToOrderListButton.setOnAction(e -> {
            try {
                // Switch to OrderList GUI
                new OrderList().start(new Stage());
                stage.close(); // Close the current FoodItemsGUI stage
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // HBox for button alignment at bottom-right
        HBox buttonLayout = new HBox();
        buttonLayout.setAlignment(Pos.BOTTOM_RIGHT);
        buttonLayout.getChildren().add(goToOrderListButton);
        buttonLayout.setStyle("-fx-padding: 15;");

        // Main layout (BorderPane for positioning)
        BorderPane mainLayout = new BorderPane();
        mainLayout.setCenter(vbox); // Table in the center
        mainLayout.setBottom(buttonLayout); // Button at the bottom-right

        // Scene
        Scene scene = new Scene(mainLayout, 600, 400);
        stage.setScene(scene);
        stage.show();
    }

    public ObservableList<FoodItems> getFoodItems() {
        return FXCollections.observableArrayList(FoodItems.FoodItemsList); // Load static list
    }

    public static void display() {
        launch();
    }
}
