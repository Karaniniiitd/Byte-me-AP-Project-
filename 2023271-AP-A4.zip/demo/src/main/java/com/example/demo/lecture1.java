package com.example.demo;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.util.EventListener;

import static javafx.application.Application.launch;

public class lecture1 extends Application  {
    Button button;
    public static void main(String[] args) {
        launch(args);
    }
//    @Override
    public void start(Stage primaryStage) throws Exception{
        primaryStage.setTitle("Hi Window");
        button = new Button();
        button.setText("Hi Button");
        button.setOnAction(e->AlertBox.display("Closewindow","hi"));
        StackPane layout = new StackPane();
        layout.getChildren().add(button);
        Scene scene = new Scene(layout,300,250);
        primaryStage.setScene(scene);
        primaryStage.show();



    }

//    @Override
//    public void handle(ActionEvent actionEvent) {
//        if(actionEvent.getSource()==button){
//            button.setText("Hi Button");
//            System.out.println("aka baka saka!");
//        }
//
//    }
}
