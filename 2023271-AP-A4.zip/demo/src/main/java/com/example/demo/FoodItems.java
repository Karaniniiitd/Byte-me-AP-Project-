package com.example.demo;
import java.util.*;
public class FoodItems implements Comparable<FoodItems> {
    private int price;
    private String name;
    private String category;
    private int availability;
    public static List<FoodItems> FoodItemsList = new ArrayList<>();
    public FoodItems(int price, String name, String category, int availability) {
        this.price = price;
        this.name = name;
        this.category = category;
        this.availability = availability;
        FoodItemsList.add(this);
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public int getAvailability() {
        return availability;
    }
    public void setAvailability(int availability) {
        this.availability = availability;
    }

    @Override
    public int compareTo(FoodItems o) {
        return Integer.compare(this.price, o.price);
    }
}
