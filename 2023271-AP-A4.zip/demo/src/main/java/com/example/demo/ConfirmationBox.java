package com.example.demo;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ConfirmationBox {
    static boolean answer;

    public static boolean display(String title) {
        Stage window = new Stage();
        window.setTitle(title);
        window.initModality(Modality.APPLICATION_MODAL);
        window.setMinWidth(300);
        window.setMinHeight(150);

        // Label to show the confirmation question
        Label label = new Label("Do you want to exit GUI mode?");
        label.setStyle("-fx-font-size: 14; -fx-font-weight: bold;");

        // Buttons
        Button yesButton = new Button("Yes");
        Button noButton = new Button("No");

        // Button actions
        yesButton.setOnAction(e -> {
            answer = true;
            window.close();
        });
        noButton.setOnAction(e -> {
            answer = false;
            window.close();
        });

        // Layout
        VBox layout = new VBox(20); // Spacing between elements set to 20
        layout.setPadding(new javafx.geometry.Insets(15));
        layout.getChildren().addAll(label, yesButton, noButton);
        layout.setAlignment(Pos.CENTER);

        // Scene
        Scene scene = new Scene(layout);
        window.setScene(scene);
        window.showAndWait();

        return answer;
    }
}
