package com.example.demo;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Review<T> {
    private T feedback;

    // Changed Map key type to CompletedOrder
    public static Map<CompletedOrder, List<Review<?>>> orderFeedback = new HashMap<>();
    public static Map<CustomerFoodItems, List<Review<?>>> itemFeedback = new HashMap<>();

    // Constructor
    public Review(T feedback) {
        this.feedback = feedback;
    }

    // Getter
    public T getReview() {
        return feedback;
    }

    // Display feedback
    public void displayReview() {
        System.out.println("Review: " + feedback.toString());
    }
}
