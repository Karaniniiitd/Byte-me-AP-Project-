package com.example.demo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class LoginTest {
    @BeforeEach
    void setUp() {
        // Clear and populate the CustomersList and adminList before each test
        Customer.CustomersList = new ArrayList<>();
        Admin.adminList = new ArrayList<>();

        // Add a sample customer
        Customer.CustomersList.add(new Customer("customer@example.com", "password123",false));

        // Add a sample admin
        Admin.adminList.add(new Admin("admin@example.com", "adminpass"));
    }

    @Test
    void testValidCustomerLogin() {
        // Simulate user input for a valid customer login
        String input = "2\ncustomer@example.com\npassword123\n";
        Scanner scanner = new Scanner(new java.io.ByteArrayInputStream(input.getBytes()));

        try {
            Users user = Main.login(scanner);
            assertNotNull(user); // Ensure a user is returned
            assertTrue(user instanceof Customer); // Ensure the user is a customer
            assertEquals("customer@example.com", user.getEmailid()); // Check email
        } catch (InvalidLoginException e) {
            fail("Valid customer login threw an exception!");
        }
    }

    @Test
    void testValidAdminLogin() {
        // Simulate user input for a valid admin login
        String input = "1\nadmin@example.com\nadminpass\n";
        Scanner scanner = new Scanner(new java.io.ByteArrayInputStream(input.getBytes()));

        try {
            Users user = Main.login(scanner);
            assertNotNull(user); // Ensure a user is returned
            assertTrue(user instanceof Admin); // Ensure the user is an admin
            assertEquals("admin@example.com", user.getEmailid()); // Check email
        } catch (InvalidLoginException e) {
            fail("Valid admin login threw an exception!");
        }
    }

    @Test
    void testInvalidLogin() {
        // Simulate user input for an invalid login
        String input = "2\ninvalid@example.com\nwrongpass\n";
        Scanner scanner = new Scanner(new java.io.ByteArrayInputStream(input.getBytes()));

        assertThrows(InvalidLoginException.class, () -> {
            Main.login(scanner);
        });
    }
}
