package com.example.demo;

import com.example.demo.Customer;
import com.example.demo.FoodItems;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class AddItemsTest {
    private Customer yourClassUnderTest; // Replace with the actual class name
    private ArrayList<FoodItems> foodItemsList;

    @BeforeEach
    void setUp() {
        // Initialize your test class
        yourClassUnderTest = new Customer("karan@2005","2005",false);
        yourClassUnderTest.cart = new ArrayList<>(); // Initialize the cart

        // Initialize the food items list
        foodItemsList = new ArrayList<>();
        FoodItems.FoodItemsList = foodItemsList;

        // Add a food item with zero availability
        FoodItems unavailableItem = new FoodItems(10, "Maggie", "Fast Food", 0); // availability is 0
        foodItemsList.add(unavailableItem);
    }

    @Test
    void testAddItemsWithZeroAvailability() {
        // Simulate user input
        String input = "Pizza\n1\nno\n"; // Try adding "Pizza" with a quantity of 1
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));
        java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(outContent));

        // Call the method
        yourClassUnderTest.additems();

        // Assert that the correct message is printed
        assertFalse(outContent.toString().contains("Not enough items in stock! Available quantity: 0"));
    }
}
