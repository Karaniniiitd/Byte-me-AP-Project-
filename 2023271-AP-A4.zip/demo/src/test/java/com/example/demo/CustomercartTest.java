package com.example.demo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class CustomercartTest {

    private Customer user; // Replace with the actual class name

    @BeforeEach
    void setUp() {
        // Initialize the user and cart for each test
        user = new Customer("karan@2005","2005",false); // Replace with your actual class name
        user.cart = new ArrayList<>();

        // Add sample food items to the available list
        FoodItems.FoodItemsList = new ArrayList<>();
        FoodItems.FoodItemsList.add(new FoodItems(300, "Pizza", "Main Course", 10));
        FoodItems.FoodItemsList.add(new FoodItems(150, "Burger", "Snacks", 5));
        FoodItems.FoodItemsList.add(new FoodItems(200, "Pasta", "Main Course", 8));
    }

    @Test
    void additems() {
        // Simulate adding an item to the cart
        String input = "Pizza\n2\nnull\nno\n"; // Simulates user input
        InputStream inputStream = new ByteArrayInputStream(input.getBytes());
        System.setIn(inputStream);

        user.additems(); // Call the additems method

        // Verify the cart contains the added item
        assertEquals(1, user.cart.size());
        CustomerFoodItems addedItem = user.cart.get(0);
        assertEquals("Pizza", addedItem.getName());
        assertEquals(300, addedItem.getPrice());
        assertEquals(2, addedItem.getQuantity());

        // Verify total price calculation
        int totalPrice = user.viewtotal();
        assertEquals(300 * 2, totalPrice);
    }

    @Test
    void modifyquantity() {
        // Add an item to the cart first
        user.cart.add(new CustomerFoodItems(300, "Pizza", "Main Course", 10, 2, "null", false));

        // Simulate modifying the quantity of an existing item
        String input = "Pizza\n4\n"; // Simulates user input
        InputStream inputStream = new ByteArrayInputStream(input.getBytes());;
        System.setIn(inputStream);

        user.modifyquantity(); // Call the modifyquantity method

        // Verify the modified quantity
        CustomerFoodItems modifiedItem = user.cart.get(0);
        assertEquals(4, modifiedItem.getQuantity());

        // Verify the recalculated total price
        int totalPrice = user.viewtotal();
        assertEquals(300 * 4, totalPrice);
    }

    @Test
    void viewtotal() {
        // Add multiple items to the cart
        user.cart.add(new CustomerFoodItems(300, "Pizza", "Main Course", 10, 2, "null", false));
        user.cart.add(new CustomerFoodItems(150, "Burger", "Snacks", 5, 3, "null", false));

        // Calculate the total price
        int totalPrice = user.viewtotal();

        // Verify the total price is correct
        assertEquals((300 * 2) + (150 * 3), totalPrice);
    }
}
